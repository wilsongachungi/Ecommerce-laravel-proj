<template>
    <section
      class="h-[50vh] bg-cover bg-center bg-no-repeat"
      style="background-image: url('https://ncube.com/wp-content/uploads/2020/06/types-of-ecommerce.jpg');"
    >
      <div class="flex flex-col justify-center items-center h-full bg-black bg-opacity-50 px-4 text-center">
        <h1 class="mb-4 text-3xl font-extrabold tracking-tight leading-tight text-white md:text-4xl lg:text-5xl">
            Join thousands of happy customers who trust us for quality, value, and innovation.
        </h1>
        <p class="text-md font-normal text-gray-200 lg:text-lg sm:px-10 xl:px-32">
            Start shopping today and experience the future of eCommerce!
        </p>
      </div>
    </section>
  </template>
