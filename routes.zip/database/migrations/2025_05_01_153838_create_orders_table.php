<?php

use App\Models\User;
use App\Models\UserAddress;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
       Schema::create('orders', function (Blueprint $table) {
    $table->id();
    $table->decimal('total_price', 20, 2);
    $table->string('status', 45);
    $table->string('session_id', 255);

    // Assumes UserAddress maps to 'user_addresses' table
    $table->foreignIdFor(UserAddress::class)
        ->constrained()
        ->cascadeOnUpdate()
        ->cascadeOnDelete();

    $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
    $table->foreignId('updated_by')->nullable()->constrained('users')->nullOnDelete();

    $table->timestamps();
});

    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('orders');
    }
};
